# อัปเดต chatbot และชื่อเว็บ

เวอร์ชันนี้ใช้ชื่อ **อ้ายโอห์ม แฟนเชลซี** ทั้งหน้าแรกและ Dashboard

## เพิ่มอะไร

- ปุ่มหุ่นยนต์สไตล์ 3D ที่มุมขวาบนของเมนู กดแล้วเปิดหน้าต่างแชท
- คำถามลัดและช่องพิมพ์คำถาม ตอบเรื่องประวัติ นักเตะ โค้ช ความฝัน และช่องทางติดต่อ
- อ่านเฉพาะคำตอบที่เผยแพร่ใน `bot_knowledge` ผ่าน Supabase publishable key
- มีคำตอบสำรองจากข้อมูลเว็บไซต์เมื่อโหลดคำตอบจาก Supabase ไม่สำเร็จ
- ไม่บันทึกบทสนทนา ไม่ใช้ localStorage/cookies ไม่เรียก Auth และไม่ส่งข้อความไปเขียนฐานข้อมูล
- ไม่ได้เชื่อมโมเดล AI หรือข้อมูลข่าวฟุตบอลสด
- รองรับ Escape, โฟกัสใน dialog, ปุ่มเริ่มใหม่ และหน้าจอมือถือ

## ไฟล์ที่เปลี่ยน

```text
dist/index.html
dist/dashboard.html
dist/assets/css/chatbot.css
dist/assets/js/chat-config.js
dist/assets/js/chatbot.js
```

`chat-config.js` มีเฉพาะ publishable key ที่อนุญาตให้เปิดเผยบนหน้าเว็บ ตารางแชทส่วนตัวยังคงถูกป้องกันด้วย RLS และ widget เวอร์ชันนี้ไม่เข้าถึงตารางเหล่านั้น

## อัปโหลดไป GitHub

1. แตก `chelsea-chatbot-update.zip`
2. เปิด repository `wanatsarutpungkasem-lgtm/chelsea-` แล้วเลือก Add file > Upload files
3. ลากโฟลเดอร์ `dist` จากชุดอัปเดตลงไปทั้งโฟลเดอร์ พร้อมไฟล์ `netlify.toml` ที่ระดับหลัก
4. Commit changes ไป `main`
5. รอ Netlify deploy ใหม่เป็น Ready แล้วรีเฟรช `https://fan-chelsea.netlify.app`

อย่าอัปโหลดไฟล์ ZIP เข้า repository โดยไม่แตกไฟล์ก่อน

## สถานะการส่งขึ้นระบบ

สร้างและทดสอบบนเครื่องแล้ว แต่ GitHub connector ยังตอบ `403 Resource not accessible by integration` เมื่ออัปโหลดไฟล์ จึงยังไม่ได้อัปเดต frontend บน Netlify ผ่าน connector

ข้อมูลคำตอบใน Supabase ถูกปรับชื่อและข้อความนโยบายให้ตรงกับโหมดไม่บันทึกประวัติแล้ว

## ผลทดสอบ

- JavaScript syntax checks ผ่าน
- ลิงก์ CSS/JS และชื่อใหม่ครบทั้งสองหน้า
- เปิดแชทและตอบคำถามนักเตะ/นโยบายประวัติได้
- ปิดด้วย Escape ได้ และรีเฟรชแล้วไม่มีบทสนทนาเดิม
- ตรวจหน้าจอมือถือแล้วไม่มี horizontal overflow
- ตรวจหลังทดสอบ: chat_sessions = 0, chat_messages = 0
